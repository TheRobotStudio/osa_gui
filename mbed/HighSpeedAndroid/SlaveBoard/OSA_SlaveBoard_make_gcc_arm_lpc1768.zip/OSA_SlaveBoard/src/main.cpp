/*
 * Copyright (c) 2017, The Robot Studio
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file main.cpp
 * @author Cyril Jourdan
 * @date Mar 08, 2017
 * @version 2.0.0
 * @brief main file for the Slave Board, that comminucates over SPI bus to the Master Board and over CAN bus to the motor controllers.
 *
 * Contact: cyril.jourdan@therobotstudio.com
 * Created on : Feb 27, 2013
 */
 
#define COMPILE_MAIN_CODE
#ifdef  COMPILE_MAIN_CODE

/*! Includes */
#include "../include/eposCmd.h"

/*! Defines */
#define OPEN_ARROW          0x3C //0x3C is ASCII for '<' = 60
#define CLOSE_ARROW         0x3E //0x3E is ASCII for '>' = 62

//SPI RxTx FIFO bits
//#define TNF 0x02
//#define TFE 0x01
#define RNE 0x04

/*! Variables */
SPISlave device(p5, p6, p7, p8); //mosi, miso, sclk, ssel
DigitalIn sync_master(p11);

DigitalOut logicPin(p26); //to record with Logic analyser on an event, pin high.

uint8_t numberEposBoards = 0;

char dataChecksum = 0x00;
char cmdChecksum = 0x00;

uint8_t writeBufferSPI[NUMBER_MAX_EPOS_PER_SLAVE][NUMBER_BYTES_PER_MSG];
uint8_t readBufferSPI[NUMBER_MAX_EPOS_PER_SLAVE][NUMBER_BYTES_PER_MSG];

/*! Functions */

/*! \fn bool verifyChecksum()
 *  \brief check the data comming from the master over SPI.
 *  \return bool
 */
bool verifyChecksum() 
{      
    for(int i=0; i<NUMBER_MAX_EPOS_PER_SLAVE; i++)
    {
        for(int j=0; j<NUMBER_BYTES_PER_MSG; j++)
        {
            cmdChecksum += readBufferSPI[i][j];
        }
    }
    
    cmdChecksum++; //add 1 to obtain 0x00
    
    //pc.printf("sum 0x%02X\n\r", cmdChecksum);
    
    if(cmdChecksum == 0x00) return true;
    else return false;
}

/*! \fn void calculateSPIChecksum()
 *  \brief compute checksum for the data sent to the master over SPI
 *  \return void
 */
void calculateSPIChecksum() 
{   
    int sum = 0;
           
    for(int i=0; i<NUMBER_MAX_EPOS_PER_SLAVE; i++)
    {
        for(int j=0; j<NUMBER_BYTES_PER_MSG; j++)
        {
            sum += writeBufferSPI[i][j];
        }
    }       
        
    dataChecksum = (char)(~sum); //reverse 0 and 1, and cast as byte
}

/*! \fn void interrupt()
 *  \brief Interrupt function for catching CAN frames and dealing with Emergency error frames
 *  \return void
 */
void interrupt()
{
    CANMessage canmsg;
    uint64_t data = 0x0000000000000000; //64 bits
    uint8_t nodeID = 0;
    int16_t cobID = 0;
        
    //read the can message that has triggered the interrupt
    cantoepos.read(canmsg);   
    
    //pc.printf("Interrupt frame : [%02X] [%02X %02X %02X %02X %02X %02X %02X %02X]\r\n", canmsg.id, canmsg.data[7], canmsg.data[6], canmsg.data[5], canmsg.data[4], canmsg.data[3], canmsg.data[2], canmsg.data[1], canmsg.data[0]);
    
    nodeID = 0x07F & canmsg.id;
    cobID = 0x0F80 & canmsg.id;

    for(int i=0; i<=canmsg.len; i++)
    {
        data = data | (canmsg.data[i]<<i*8);        
    }
    
    //check nodeID first
    if((nodeID >= 1) && (nodeID <= numberEposBoards)) 
    {
        switch(cobID)
        {       
            case COB_ID_TRANSMIT_PDO_1_ENABLE : //getPositionVelocity
            
                //pc.printf("TPDO1 Node ID : [%d], PDO COB-ID [%02X], data = %d\n", nodeID, cobID, data);
                
                int32_t pos = (canmsg.data[3]<<24 | canmsg.data[2]<<16 | canmsg.data[1]<<8 | canmsg.data[0]); //0x00000000FFFFFFFF & data;                
                int32_t vel = (canmsg.data[7]<<24 | canmsg.data[6]<<16 | canmsg.data[5]<<8 | canmsg.data[4]);
                                               
                if(motorArray[nodeID-1].inverted == true) //!< change sign
                {
                    position[nodeID-1] = -1*pos;
                    velocity[nodeID-1] = -1*vel;
                }
                else
                {
                    position[nodeID-1] = pos;
                    velocity[nodeID-1] = vel;
                }
                
                break;
                
            case COB_ID_TRANSMIT_PDO_2_ENABLE : //getCurrentFollErrStatusword
            
                //pc.printf("TPDO2 Node-ID[%d] COB-ID[%02X] data[%ld]\n\r", nodeID, cobID, data); 
                //pc.printf("IT[%02X] [%02X %02X]\r\n", canmsg.id, canmsg.data[5] ,  canmsg.data[4]);
                
                int16_t curr  = (canmsg.data[1]<<8 | canmsg.data[0]); //0x000000000000FFFF & data;
                int16_t follErr = (canmsg.data[3]<<8 | canmsg.data[2]); //(0x00000000FFFF0000 & data) >> 16;
                uint16_t statwrd = (canmsg.data[5]<<8 | canmsg.data[4]); //(0x0000FFFF00000000 & data) >> 32;
             
                if(motorArray[nodeID-1].inverted == true) curr = -1*curr; //change sign
                current[nodeID-1] = curr;
                followingError[nodeID-1] = follErr;
                statusword[nodeID-1] = statwrd;
                
                //pc.printf("TPDO2 Node-ID[%d] curr[%d] follErr[%d] statwrd[%d]\n\r", nodeID, curr, follErr, statwrd);
                
                break;
                
            case COB_ID_TRANSMIT_PDO_3_ENABLE : //getModesOfOperation
            
                //pc.printf("TPDO3 Node ID : [%d], PDO COB-ID [%02X], data = %d\n", nodeID, cobID, data);  
                
                int8_t modesOfOp = 0x00000000000000FF & data;;
                                              
                modesOfOperation[nodeID-1] = modesOfOp;
                
                break;
                
            case COB_ID_TRANSMIT_PDO_4_ENABLE : //getIncEnc1CntAtIdxPls
            
                //pc.printf("TPDO4 Node ID : [%d], PDO COB-ID [%02X], data = %d\n", nodeID, cobID, data);
                
                uint32_t incEnc1 = 0x00000000FFFFFFFF & data;;
                
                incEnc1CntAtIdxPls[nodeID-1] = incEnc1;
                
                break; 
             
            case COB_ID_EMCY_DEFAULT : //Emergency frame
                //pc.printf("Emergency frame, Node ID : [%d], PDO COB-ID [%02X], data = %02X\n", nodeID, cobID, data);
                //pc.printf("EF [%02X][%02X %02X %02X %02X %02X %02X %02X %02X]\n", canmsg.id, canmsg.data[7], canmsg.data[6], canmsg.data[5], canmsg.data[4], canmsg.data[3], canmsg.data[2], canmsg.data[1], canmsg.data[0]);
                pc.printf("EF%02X-%02X%02X\n\r", canmsg.id, canmsg.data[1], canmsg.data[0]);
                ledchain[1] = 1;            
                //nh.logerror("Emergency frame");
                boardStatus[nodeID-1] = 1;                
                //first step : fault reset on controlword
                //pc.printf("Node %d - STEP 1 - faultResetControlword\n", nodeID);
                
                //Debug for fault detection on brachii
                faultResetControlword(nodeID);        //TODO replace with RPDO         
                break;  
                
            case COB_ID_SDO_SERVER_TO_CLIENT_DEFAULT : //SDO Acknoledgement frame
                int32_t regData = 0x00000000;
                regData = (int32_t)data;
                
                //pc.printf("Node %d - regData [%02X]\n", nodeID, regData);
                                
                if(regData == 0x00604060) //Controlword
                {
                    if(boardStatus[nodeID-1] == 1)
                    {
                        boardStatus[nodeID-1] = 2;                      
                        //second step : shutdown controlword
                        //pc.printf("Node %d - STEP 2 - shutdownControlwordIT\n", nodeID);
                        shutdownControlwordIT(nodeID); //TODO replace with RPDO 
                    }
                    else if(boardStatus[nodeID-1] == 2)
                    {
                        boardStatus[nodeID-1] = 3;                      
                        //third step : Switch On & Enable Operation on Controlword
                        //pc.printf("Node %d - STEP 3 - switchOnEnableOperationControlwordIT\n", nodeID);
                        switchOnEnableOperationControlwordIT(nodeID); //TODO replace with RPDO 
                    }
                    else if(boardStatus[nodeID-1] == 3)
                    {
                        boardStatus[nodeID-1] = 4;
                        //ask for statusword to check if the board has reset well
                        //pc.printf("Node %d - STEP 4 - getStatusword\n", nodeID);
                        //TODO getStatusword(nodeID);
                    }
                } 
                else if(regData == 0x0060414B) //read Statusword
                {
                    //int32_t swData = 0x00000000;
                    
                    //pc.printf("Node %d - Statusword [%02X]\n", nodeID, canmsg.data[4]);
                    //pc.printf("Statusword frame : [%02X] [%02X %02X %02X %02X %02X %02X %02X %02X]\n", canmsg.id, canmsg.data[7], canmsg.data[6], canmsg.data[5], canmsg.data[4], canmsg.data[3], canmsg.data[2], canmsg.data[1], canmsg.data[0]);
                    
                    if(boardStatus[nodeID-1] == 4)
                    {
                        //swData = data >> 32;
                        int8_t fault = 0x00;
                        fault = (canmsg.data[4] & 0x08) >> 3;
                                               
                        if(fault == 0) //reset OK
                        {
                            boardStatus[nodeID-1] = 0; //Board is reset and enable OK
                            pc.printf("%d OK\n\r", nodeID);
                            ledchain[1] = 0;
                        }
                        else //try to reset again
                        {
                            //pc.printf("Node %d - try to reset again\n", nodeID);
                            boardStatus[nodeID-1] = 1;                
                            //go back to first step : fault reset on controlword
                            //pc.printf("Node %d - STEP 1 - faultResetControlword\n", nodeID);
                            faultResetControlword(nodeID);       //TODO replace with RPDO                  
                        }
                    }  
                }                                            
                break;  
                           
            default :
                pc.printf("Unknown frame [%02X][%02X %02X %02X %02X %02X %02X %02X %02X]\n\r", canmsg.id, canmsg.data[7], canmsg.data[6], canmsg.data[5], canmsg.data[4], canmsg.data[3], canmsg.data[2], canmsg.data[1], canmsg.data[0]);                            
        } //end switch
    }
    else
    {
        pc.printf("NODEID ERROR\n\r");    
    }
}

/*! \fn void commandPlayer()
 *  \brief function that send CAN commands to the motors, called in main every cycle.
 *  \return void
 */
void commandPlayer()
{
    //at least one cmd played.
    bool cmdPlayLED = false;
    
    //for(int i= 1; i<=numberEposBoards; i++)
    for(int i= 0; i<numberEposBoards; i++)
    {        
        //uint8_t node_ID = readBufferSPI[i][0];
        uint8_t node_ID = i+1;
        uint8_t command = readBufferSPI[i][0];
        int32_t value = readBufferSPI[i][1] + (readBufferSPI[i][2]<<8) + (readBufferSPI[i][3]<<16) + (readBufferSPI[i][4]<<24);
        
        //pc.printf("cmd[%d] val[%d]\r\n", command, value);
        
        switch (command)
        {
            case SET_TARGET_POSITION:
                setTargetPosition(node_ID, value);
                break;
            
            case SET_TARGET_VELOCITY:
                setTargetVelocity(node_ID, value);
                break;
                
            case SET_PROFILE_ACCELERATION:
                setProfileAcceleration(node_ID, value);
                break;
                
            case SET_PROFILE_DECELERATION:
                setProfileDeceleration(node_ID, value);
                break;
                
            case SET_PROFILE_VELOCITY:
                setProfileVelocity(node_ID, value);
                break;
                
            case SET_CONTINUOUS_CURRENT_LIMIT:
                setContinuousCurrentLimit(node_ID, value);
                break;
            
            case SET_CONTROLWORD:
                setControlword(node_ID, value);
                break;
                
            case SET_CURRENT_MODE_SETTING_VALUE:
                setCurrentModeSettingValue(node_ID, value);
                break;
                
            case SET_MAXIMAL_SPEED_IN_CURRENT_MODE:
                setMaximalSpeedInCurrentMode(node_ID, value);
                break;
                
            case SET_MODES_OF_OPERATION:
                switch(value)         
                {
                    case INTERPOLATED_POSITION_MODE:
                        setModesOfOperation(node_ID, VALUE_INTERPOLATED_POSITION_MODE);    
                        cmdPlayLED = true;                      
                        break;
                        
                    case PROFILE_VELOCITY_MODE:
                        setModesOfOperation(node_ID, VALUE_PROFILE_VELOCITY_MODE);
                        cmdPlayLED = true;
                        break;
                        
                    case PROFILE_POSITION_MODE:
                        //pc.printf("cmd[%d] val[%d]\r\n", command, value);         
                        setModesOfOperation(node_ID, VALUE_PROFILE_POSITION_MODE); 
                        cmdPlayLED = true;     
                        break;
                        
                    case POSITION_MODE:
                        setModesOfOperation(node_ID, VALUE_POSITION_MODE); 
                        cmdPlayLED = true;                
                        break;
                        
                    case VELOCITY_MODE:         
                        setModesOfOperation(node_ID, VALUE_VELOCITY_MODE);
                        cmdPlayLED = true;  
                        break;
                        
                    case CURRENT_MODE:                
                        setModesOfOperation(node_ID, VALUE_CURRENT_MODE);
                        cmdPlayLED = true;
                        break;
                    
                    case NO_MODE:                        
                        break;
                        
                    default:
                        break;
                }
                //setModesOfOperation(i, value);
                break;
                
            case SEND_DUMB_MESSAGE:
                if(!cmdPlayLED) ledchain[3] = 0;    //switch off when slave is idle, i.e. all cmd in a set are 0xFF.
                break;
                
            default:
                if(!cmdPlayLED) ledchain[3] = 0;    //switch off when slave is idle, i.e. all cmd in a set are 0xFF.
                break;
                
        }
  
        if(cmdPlayLED) ledchain[3] = 1;    //switch on if cmd is applied.
            
        wait_us(10);
    }
}

/*! \fn void updateTxSPIBuffer()
 *  \brief 
 *  \return void
 */
void updateTxSPIBuffer()
{
    for(int i=1; i<=numberEposBoards; i++)
    {
        //uint8_t node_id = i;
                              
        getPositionVelocity(i);
        wait_us(200);   
        getCurrentFollErrStatusword(i);
        wait_us(200);          
        //wait_us(200);                 
    }
      
    //TODO try to add a pause here, or turn a flag in the interrupt when the values are updated  
      
    //build the motorDataSet_msg          
    for(int i=0; i<numberEposBoards; i++)
    {    
        uint8_t node_id = i+1;        
        int32_t pos = position[node_id-1];
        int16_t statwrd = statusword[node_id-1];
        
        //position
        writeBufferSPI[i][0] = pos;
        writeBufferSPI[i][1] = pos>>8;
        writeBufferSPI[i][2] = pos>>16;
        writeBufferSPI[i][3] = pos>>24;
        
        //current
        writeBufferSPI[i][4] = current[node_id-1];
        writeBufferSPI[i][5] = current[node_id-1]>>8;
            
        //custom value : force, board status...       
        writeBufferSPI[i][6] = statwrd;
        writeBufferSPI[i][7] = statwrd>>8;
          
        //pc.printf("[%d] pos=%d cur=%d\n", node_id, position[node_id-1], current[node_id-1]);                                    
    }
}

/*! \fn void initBufferSPI()
 *  \brief 
 *  \return void
 */
void initBufferSPI()
{
    //init the SPI arrays
    for(int i=0; i<NUMBER_MAX_EPOS_PER_SLAVE; i++)
    { 
        for(int j=0; j<NUMBER_BYTES_PER_MSG; j++)
        {             
            writeBufferSPI[i][j] = 0x00;
            readBufferSPI[i][j] = 0x00;            
        }
    }
}

/*! \fn void calibrate()
 *  \brief calibration routine.
 *  \return void
 */
void calibrate()
{        
    pc.printf("- Start Calibration\n\r");
    
    for(int i=1; i<=numberEposBoards; i++)
    { 
        //set default parameters
        
        //RPDO2
        setProfileAcceleration(i, 1010);
        wait_ms(1);
        setProfileDeceleration(i, 1020);        
        wait_ms(1);
        
        //RPDO3
        setControlword(i, 271); //read from EPOS Studio while setting a current value in current mode.
        wait_ms(1);
        setProfileVelocity(i, 850);
        wait_ms(1);
        setContinuousCurrentLimit(i, 10100); //10000 for EPOS2 70/10, see documentation
        wait_ms(1);
        
        //RPDO4
        setMaximalSpeedInCurrentMode(i, 950);
        wait_ms(1);
        setModesOfOperation(i, VALUE_CURRENT_MODE); //set all boards to current mode
        wait_ms(1);
    }

    ledchain[2] = 1;
    
    wait_ms(20); 
    //
    for(int j=1; j<=numberEposBoards; j++)
    {
        setCurrentModeSettingValue(j, motorArray[j-1].current);
        wait_ms(1);
    }
        
    ledchain[3] = 1;
    
    wait_ms(1000);
    
    for(int i=1; i<=numberEposBoards; i++)
    {             
        //TPDO : get data once to fill in the arrays
        getPositionVelocity(i);
        wait_ms(1);
        getCurrentFollErrStatusword(i);
        wait_ms(1);
        
        //print results to check things are working properly
        pc.printf("[%d] pos=%d vel=%d cur=%d stwrd=%d\r\n", i, position[i-1], velocity[i-1], current[i-1], statusword[i-1]); 
    }   
}

/*! \fn int main() 
 *  \brief main function.
 *  \return int
 */
int main() 
{
    //Serial setup for debug          
    pc.baud(115200);    
    pc.printf("***** trs_slave_v2 - The Robot Studio *****\n\r");    
    pc.printf("*** Start Slave Main ***\n\r");
    
    //SPI setup
    device.format(8, 0);
    device.frequency(1000000);
    
    logicPin = 0;
        
    uint8_t my_val = 0x00; //to read and empty the SPI FIFO buffer 
    
    initBufferSPI();
    char rByte = 0x00;
    
    char threeArrows = 0;
    //bool threeArrowsFound = false;
    bool slaveSelected = false;
    bool checksumReceived = false;
    bool cmdValid = false;
    
    int i = 0; //msg
    int j = 0; //byte number

    ledchain[0] = 1; 
    
    pc.printf("--- Read local config file : input.cfg\n\r");
    //configure the motors, type, invertion, and nodeID
    if(!configureSlaveBoard()) return -1; //exit main if the file failed to read
    
    pc.printf("--- Initialise EPOS boards ---\n\r");    
    
    wait_ms(1000); //wait 1s to let the time for the EPOS2 to boot up
    
    numberEposBoards = 1; //assume 1 EPOS board at least
    
    while(initEposBoard(numberEposBoards) == EPOS2_OK)
    {
        numberEposBoards++;
    } //assumes all the connected nodes on the CAN bus have continuous node IDs starting with 1. 
        
    numberEposBoards--; //to get the correct number, assuming the first one worked
    
    ledchain[1] = 1;
    
    pc.printf("--- Enable Interrupts ---\n\r"); 
    //attach the interrupt function
    cantoepos.attach(&interrupt);
    __enable_irq();
    
    pc.printf("--- Calibrate Arm ---\n\r");
  
    calibrate();   
    
    device.reply(0x62); //Prime SPI with first reply

    //gather first pack of data
    //get the sensor values       
    updateTxSPIBuffer();      
      
    //update checksum
    calculateSPIChecksum();    
    
    //then start the main loop
    pc.printf("--- Start main loop ---\n\r"); 
    
    //Turn off all the LEDs
    ledchain[0] = 0; //ON when it is selected by the Master Board
    ledchain[1] = 0; //ON when a CAN Emergency frame is received     
    ledchain[2] = 0; //Just used in calibration
    ledchain[3] = 0; //ON when a command is sent to a motor
                   
    while(1) 
    {                      
        ledchain[0] = 0; //not selected by master
        ledchain[3] = 0; //no commands played
                     
        //wait, the master will put the pin high at some point, for 10us
        while(sync_master == 0)
        {
            wait_us(1);  
        }      
        
        slaveSelected = true;
        ledchain[0] = 1;       
        
        while(LPC_SSP1->SR & RNE)       // While RNE-Bit = 1 (FIFO receive buffer not empty)...
        my_val = LPC_SSP1->DR;          // Read the byte in the buffer
                      
        //reset for a new message
        i = 0;
        j = 0;
        threeArrows = 0;
        //threeArrowsFound = false;
        checksumReceived = false;               
        
        __disable_irq(); //disable CAN interrupt during the use of SPI
        
        /*logicPin = 1;
        wait_us(7);  
        logicPin = 0;
          */              
        while(slaveSelected)
        {   
            /*logicPin = 1;
            wait_us(3);  
            logicPin = 0;*/
                              
            //SPI polling
            if(device.receive()) 
            { 
                //pc.printf("receive\n");     
                rByte = device.read();   // Read byte from master
                //pc.printf("0x%02X ", rByte);
                
                if(threeArrows < 3)
                {
                    if(rByte == OPEN_ARROW) 
                    {   
                        threeArrows++;                        
                        //pc.printf("3A++\n\r");
                    }
                    else 
                    {
                        //threeArrows = 0; 
                        //startReceiving = false;   
                        //pc.printf("error3A\n");  
                        //slaveSelected = false; 
                    }
                    
                    if(threeArrows == 3) 
                    {      
                        device.reply(writeBufferSPI[i][j]);
                        //threeArrowsFound = true;
                    }
                    else
                    {
                        device.reply(0x62); //close arrow : >
                    }    
                }
                else
                {                
                    readBufferSPI[i][j] = rByte;
                                    
                    j++; //write next byte next time
                     
                    if(j >= NUMBER_BYTES_PER_MSG)
                    {
                        j = 0;
                        i++; //next node 
                        
                        if(i >= NUMBER_MAX_EPOS_PER_SLAVE)
                        {                            
                            //finished reading the array                        
                            /*
                            for(int n=0; n<1; n++)
                            {
                                pc.printf("0x%02X 0x%02X 0x%02X 0x%02X 0x%02X 0x%02X 0x%02X\n", readBufferSPI[n][0], readBufferSPI[n][1], readBufferSPI[n][2], readBufferSPI[n][3], readBufferSPI[n][4], readBufferSPI[n][5], readBufferSPI[n][6]);
                            }                            
                            */
                                                        
                            //reset
                            threeArrows = 0;
                            i = 0;
                            j = 0;
                            slaveSelected = false; //to end the while loop                          
                        }             
                    } 
                                                  
                    if(slaveSelected) device.reply(writeBufferSPI[i][j]); 
                    else device.reply(dataChecksum);   //checksum
                }                                     
            }//if
            
            wait_us(1);
            
        }//while(slaveSelected)
    
        //read the checksum
        while(!checksumReceived)
        {
            //pc.printf("w");
            if(device.receive()) 
            {
                cmdChecksum = device.read();
                //pc.printf("%02X\n", cmdChecksum);
                cmdValid = verifyChecksum();                 
                checksumReceived = true; //exit while loop
            }
            
            wait_us(1);
        }  
        
        __enable_irq(); //enable CAN interrupt
     
        /*
        //print some data:
        for(int n=0; n<1; n++)
        {
            pc.printf("%02X %02X %02X %02X %02X %02X %02X %02X\n", readBufferSPI[n][0], readBufferSPI[n][1], readBufferSPI[n][2], readBufferSPI[n][3], readBufferSPI[n][4], readBufferSPI[n][5], readBufferSPI[n][6], readBufferSPI[n][7]);
        }  
        */
        //pc.printf("%02X\n", readBufferSPI[0][4]);
           
        wait_us(30);
        
        //if checksum is correct, then play the cmds
        if(cmdValid)
        {
            //play the commands     
            commandPlayer();     
            cmdValid = false; //reset for next packet  
        }
              
        //get the sensor values ready to be sent for the next loop   
        //update the writeBufferSPI
        updateTxSPIBuffer();    //test with known data first
        
        //compute checksum        
        calculateSPIChecksum();
              
        wait_us(10);                                            
    }// main while end      
    
    return 0;     
}// main end

#endif //COMPILE_MAIN_CODE
