/*
 * Copyright (c) 2017, The Robot Studio
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
 
 /**
 * @file robot.cpp
 * @author Cyril Jourdan
 * @date Mar 03, 2017
 * @version 2.0.0
 * @brief implementation file for Robot
 *
 * Contact: cyril.jourdan@therobotstudio.com
 * Created on : Nov 16, 2015
 */
 
/*! Includes */ 
#include "../include/robot.h"

/*! Variables */
Serial pc(USBTX, USBRX);
Motor motorArray[NUMBER_MAX_EPOS_PER_SLAVE] = {0, NONE, false, 0};

/*! Functions */
/*! \fn bool configureSlaveBoard()
 *  \brief Configure the Slave Board from a config file. 
 *  \return bool true if it succeeds, false if not.
 */
bool configureSlaveBoard()
{
    ConfigFile cfg;
    LocalFileSystem local("local");
    
    char *motorCfg[3][16] = {{"motor1_type", "motor2_type", "motor3_type", "motor4_type", "motor5_type", "motor6_type", "motor7_type", "motor8_type", "motor9_type", "motor10_type", 
                              "motor11_type", "motor12_type", "motor13_type", "motor14_type", "motor15_type", "motor16_type",}, 
                             {"motor1_inverted", "motor2_inverted", "motor3_inverted", "motor4_inverted", "motor5_inverted", "motor6_inverted", "motor7_inverted", "motor8_inverted", "motor9_inverted", "motor10_inverted", 
                              "motor11_inverted", "motor12_inverted", "motor13_inverted", "motor14_inverted", "motor15_inverted", "motor16_inverted",},
                             {"motor1_current", "motor2_current", "motor3_current", "motor4_current", "motor5_current", "motor6_current", "motor7_current", "motor8_current", "motor9_current", "motor10_current", 
                              "motor11_current", "motor12_current", "motor13_current", "motor14_current", "motor15_current", "motor16_current",}
                             };
    char value[BUFSIZ];
    
    pc.printf("configureSlaveBoard\n\r");
    
    //Open and read the file 
    if(cfg.read("/local/input.cfg"))
    {
        pc.printf("cfg.read OK\n\r");       
        
        for(int i=0; i<NUMBER_MAX_EPOS_PER_SLAVE; i++)        
        {                         
            //Set the node ID
            motorArray[i].nodeID = i+1;    
        
            cfg.getValue(motorCfg[0][i], &value[0], sizeof(value));
            
            //Set the motor type        
            switch(value[0])
            {
            
                case 0x30: //0x30 is ASCII for '0'
                    motorArray[i].motorType = NONE;
                    pc.printf("motorArray[%d].motorType = NONE\n\r", i);
                    break;
                
                case 0x31: //0x31 is ASCII for '1'
                    motorArray[i].motorType = DCX10;
                    pc.printf("motorArray[%d].motorType = DCX10\n\r", i);
                    break;
                    
                case 0x32: //0x32 is ASCII for '2'
                    motorArray[i].motorType = DCX14;
                    pc.printf("motorArray[%d].motorType = DCX14\n\r", i);
                    break;
                
                case 0x33: //0x33 is ASCII for '3'
                    motorArray[i].motorType = DCX16;
                    pc.printf("motorArray[%d].motorType = DCX16\n\r", i);
                    break;
                
                case 0x34: //0x33 is ASCII for '4'
                    motorArray[i].motorType = DCX22;
                    pc.printf("motorArray[%d].motorType = DCX22\n\r", i);
                    break;
                    
                case 0x35: //0x34 is ASCII for '5'
                    motorArray[i].motorType = RE13;
                    pc.printf("motorArray[%d].motorType = RE13\n\r", i);
                    break;
                    
                case 0x36: //0x33 is ASCII for '6'
                    motorArray[i].motorType = ECI40;
                    pc.printf("motorArray[%d].motorType = ECI40\n\r", i);
                    break;
                
                case 0x37: //0x35 is ASCII for '7'
                    motorArray[i].motorType = EC90;
                    pc.printf("motorArray[%d].motorType = EC90\n\r", i);
                    break;
                        
                default:
                    return false;
                    break;
            }
            
            //Set the inverted boolean
            cfg.getValue(motorCfg[1][i], &value[0], sizeof(value));
            
            if(value[0] == 0x30)
            {
                motorArray[i].inverted = false;
                pc.printf("motorArray[%d].inverted = false\n\r", i);
            }
            else if(value[0] == 0x31)
            {
                motorArray[i].inverted = true;
                pc.printf("motorArray[%d].inverted = true\n\r", i);
            }
            
            //Set the default current
            cfg.getValue(motorCfg[2][i], &value[0], sizeof(value));            
            motorArray[i].current = atoi(value);            
            pc.printf("motorArray[%d].current = %d\n\r", i, motorArray[i].current);            
        }
        
        return true;
    }
    else
    {
        pc.printf("cfg.read ERROR\n\r");
        
        return false;    
    }
}
