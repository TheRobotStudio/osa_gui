/**
 * Copyright (c) 2017, The Robot Studio
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
 
 /**
 * @file main.cpp
 * @author Cyril Jourdan
 * @date Mar 03, 2017
 * @version 2.0.0
 * @brief main file for the Master Bord, that communicates with RS232 to the computer and SPI to the Slave Boards.
 *
 * Contact: cyril.jourdan@therobotstudio.com
 * Created on : Feb 28, 2013
 */
 
/*! Includes */ 
#include"mbed.h"

#define MODSERIAL_DEFAULT_RX_BUFFER_SIZE 1024 //512
#define MODSERIAL_DEFAULT_TX_BUFFER_SIZE 1024
#include "MODSERIAL.h"

/*! Defines */
#define NUMBER_MAX_EPOS_PER_SLAVE  16
#define NUMBER_SLAVE_BOARDS         6
#define NUMBER_MSG_PER_PACKET       NUMBER_MAX_EPOS_PER_SLAVE*NUMBER_SLAVE_BOARDS //96
#define NUMBER_BYTES_PER_MSG        5 //1 byte for command and 4 bytes for value (used to be 6 with nodeID included)
#define NUMBER_BYTES_TO_READ        NUMBER_BYTES_PER_MSG + 3 //+3 as padding bytes to have 8 like the data msg, (because SPI read and write at the same time = not sure)
#define FIRST_NODE_ID_SLAVE_1       1
#define FIRST_NODE_ID_SLAVE_2       FIRST_NODE_ID_SLAVE_1 + NUMBER_MAX_EPOS_PER_SLAVE
#define FIRST_NODE_ID_SLAVE_3       FIRST_NODE_ID_SLAVE_2 + NUMBER_MAX_EPOS_PER_SLAVE
#define FIRST_NODE_ID_SLAVE_4       FIRST_NODE_ID_SLAVE_3 + NUMBER_MAX_EPOS_PER_SLAVE
#define FIRST_NODE_ID_SLAVE_5       FIRST_NODE_ID_SLAVE_4 + NUMBER_MAX_EPOS_PER_SLAVE
#define FIRST_NODE_ID_SLAVE_6       FIRST_NODE_ID_SLAVE_5 + NUMBER_MAX_EPOS_PER_SLAVE
#define EPOS2_OK                    0
#define EPOS2_ERROR                 -1
//#define LOOP_PERIOD_TIME            20000 //20 ms

#define OPEN_ARROW          0x3C //< = 60
#define CLOSE_ARROW         0x3E //< = 62
#define DUMMY_BYTE          0x00
#define NUMBER_OF_ARROWS    5

/*! Variables */
//MODSERIAL ros(p28, p27, 1024, 512); // tx, rx
MODSERIAL ros(p28, p27, MODSERIAL_DEFAULT_TX_BUFFER_SIZE, MODSERIAL_DEFAULT_RX_BUFFER_SIZE); // tx, rx
Serial pc(USBTX, USBRX); //terminal for debug
DigitalOut ledchain[] = {LED1, LED2, LED3, LED4}; //used for debugging
//DigitalOut logicPin(p29); //to record with Logic analyser on an event, pin high.

SPI spi(p5, p6, p7); // mosi, miso, sclk
DigitalOut cs[NUMBER_SLAVE_BOARDS] = {p8, p9, p10, p11, p12, p13}; //Slave Mbed number 1 //chip select
DigitalOut sync_slave[NUMBER_SLAVE_BOARDS] = {p26, p25, p24, p23, p22, p21}; //test to sync the slave

char* readBufferSerial; //[NUMBER_MSG_PER_PACKET][NUMBER_BYTES_PER_MSG]; //buffer of packets read by the master (written by the ros node on pc side)
uint8_t writeBufferSPI[NUMBER_SLAVE_BOARDS][NUMBER_MAX_EPOS_PER_SLAVE][NUMBER_BYTES_TO_READ]; //buffer ready to be sent over SPI to different slaves
uint8_t readBufferSPI[NUMBER_SLAVE_BOARDS][NUMBER_MAX_EPOS_PER_SLAVE][NUMBER_BYTES_TO_READ]; //buffer read by the master on SPI bus 

Timer timer;
uint64_t begin, end;
uint8_t numberCmds[NUMBER_SLAVE_BOARDS];

bool newCmd_detected = false;
uint8_t nbArrows = 0;
 
char rByte = 0x00;
char writeChecksum[NUMBER_SLAVE_BOARDS]; //one checksum per board
char readChecksum[NUMBER_SLAVE_BOARDS];
char serialTxChecksum = 0x00;

bool fiveArrowsFound = false;
bool cmdValid = false;
bool dataValid = false;

/*! Functions */

/**
 * custom move function (copied from MODESERIAL without the end character)
 *
 * \param s
 * \param nbBytes
 * \return int counter
 */
int move(char *s, int nbBytes) //
{
    int counter = 0;
    char c;
    
    while(ros.readable()) 
    {
        c = ros.getc();        
        *(s++) = c;
        counter++;
        if(counter == nbBytes) break;
    }
    
    return counter;
}

bool verifyCmdChecksum(char* data, int length, char checksum) //verify data comming from he PC
{      
    for(int i=0; i<length; i++)
    {
        checksum += data[i];
    }        
    
    checksum++; //add 1 to obtain 0x00
        
    if(checksum == 0x00) return true;
    else 
    {
        ledchain[1] = 1;
        return false;
    }
}

bool verifyDataChecksum() //verify data comming from the slaves on SPI
{
    bool allDataValid = true;
    
    for(int k=0; k<NUMBER_SLAVE_BOARDS; k++)
    {   
        for(int i=0; i<NUMBER_MAX_EPOS_PER_SLAVE; i++)
        {
            for(int j=0; j<NUMBER_BYTES_TO_READ; j++)
            {
                readChecksum[k] += readBufferSPI[k][i][j];
            }
        }
    
        readChecksum[k]++;
        
        if(readChecksum[k] != 0x00) allDataValid = false; //toggle the flag if one of them is corrupted
    }    
    
    if(!allDataValid) ledchain[2] = 1;  
    
    return allDataValid;
}

void calculateSPIChecksum() //compute checksum for each slave to send commands over SPI
{
    for(int k=0; k<NUMBER_SLAVE_BOARDS; k++)
    {
        int sum = 0; 
        
        for(int i=0; i<NUMBER_MAX_EPOS_PER_SLAVE; i++)
        {
            for(int j=0; j<NUMBER_BYTES_TO_READ; j++)
            {
                sum += writeBufferSPI[k][i][j];
            }
        }
    
        writeChecksum[k] = (char)(~sum); //reverse 0 and 1, and cast as byte
    }
}

void calculateTxChecksum() //compute checksum for all the data sent to the PC over serial
{   
    int sum = 0;
    
    for(int k=0; k<NUMBER_SLAVE_BOARDS; k++)
    {   
        for(int i=0; i<NUMBER_MAX_EPOS_PER_SLAVE; i++)
        {
            for(int j=0; j<NUMBER_BYTES_TO_READ; j++)
            {
                sum += readBufferSPI[k][i][j];
            }
        }        
    }
    
    serialTxChecksum = (char)(~sum); //reverse 0 and 1, and cast as byte
}

// Called everytime a new character goes into
// the RX buffer. Test that character for '/'
// Note, rxGetLastChar() gets the last char that
// we received but it does NOT remove it from
// the RX buffer.
void rxCallback(MODSERIAL_IRQ_INFO *q) 
{
    //logicPin = 1;
    
    MODSERIAL *serial = q->serial;      
    rByte = serial->rxGetLastChar();
    
    if(!fiveArrowsFound)
    {
        if(nbArrows < NUMBER_OF_ARROWS)
        {
            if(rByte == CLOSE_ARROW)
            {   
                nbArrows++;  
            }
           
            if((nbArrows > 0) && (rByte != CLOSE_ARROW))
            {
                nbArrows = 0; //reset in case the previous arrows was data. 
            }
            
            if(nbArrows == NUMBER_OF_ARROWS) 
            {
                fiveArrowsFound = true;
            } 
        }
    }
    else //fiveArrowsFound, so rByte is the checksum
    {
        move(readBufferSerial, NUMBER_MSG_PER_PACKET*NUMBER_BYTES_PER_MSG);
        //pc.printf("r cs 0x%02X\n", rByte);
        //pc.printf("move %02X %02X %02X %02X %02X %02X %02X \n", readBufferSerial[0], readBufferSerial[1], readBufferSerial[2], readBufferSerial[3], readBufferSerial[4], readBufferSerial[5], readBufferSerial[6]);
        
        cmdValid = verifyCmdChecksum(readBufferSerial, NUMBER_MSG_PER_PACKET*NUMBER_BYTES_PER_MSG, rByte);               
        //if(cmdValid) pc.printf("cmdValid\n\r");        
        
        //reset
        serial->rxBufferFlush();  
        nbArrows = 0;
        fiveArrowsFound = false;      
    }   
    
    //logicPin = 0;
}
 
/*! \fn int main() 
 *  \brief main function.
 *  \return int
 */
int main() 
{
    //Deselect all mbed slaves
    for(int k=0; k<NUMBER_SLAVE_BOARDS; k++)
    {
        cs[k] = 1; 
        sync_slave[k] = 0;
    }
        
    ros.baud(460800); //460800 works, 921600 doesn't
    pc.baud(115200);
    
    // Setup the spi for 8 bit data, high steady state clock,
    // second edge capture, with a 1MHz clock rate
    spi.format(8, 0); //spi.format(8,3);
    spi.frequency(1000000); //8000000 //working : 1000000
    
    //init the SPI arrays
    for(int i=0; i<NUMBER_SLAVE_BOARDS; i++)
    { 
        for(int j=0; j<NUMBER_MAX_EPOS_PER_SLAVE; j++)
        { 
            for(int k=0; k<NUMBER_BYTES_TO_READ; k++)
            {
                writeBufferSPI[i][j][k] = 0xFF; //0x00;
                readBufferSPI[i][j][k] = 0x00;
            }
        }
        
        writeChecksum[i] = 0x00;
    }
    
    //init alloc
    readBufferSerial = (char*)malloc(NUMBER_MSG_PER_PACKET*NUMBER_BYTES_PER_MSG*sizeof(char*));
    
    //attach interrupt    
    ros.attach(&rxCallback, MODSERIAL::RxIrq);
    
    pc.printf("*** Start Master Main ***\n\r");
    
    //logicPin = 0;
 
    // Wait here until we detect a valid message in the serial RX buffer.
    while(1)
    {
        if(cmdValid) //pass it to the SPI bus
        {
            //logicPin = 1;
               
            //init the SPI arrays
            for(int i=0; i<NUMBER_SLAVE_BOARDS; i++)
            { 
                for(int j=0; j<NUMBER_MAX_EPOS_PER_SLAVE; j++)
                { 
                    for(int k=0; k<NUMBER_BYTES_TO_READ; k++)
                    {
                        writeBufferSPI[i][j][k] = 0xFF; //0x00; //mode -1 (or 0xFF) for null command
                        readBufferSPI[i][j][k] = 0x00;
                    }
                }
                
                writeChecksum[i] = 0x00;
            }
            /*
            //init nb cmds per slave //useless ?
            for(int i=0; i<NUMBER_SLAVE_BOARDS; i++)
            {
                numberCmds[i] = 0;
            }
            */
            //logicPin = 0;
            
            //sort messages for each slave
            for(int i=0; i<NUMBER_MSG_PER_PACKET*NUMBER_BYTES_PER_MSG; i++) //i+=NUMBER_BYTES_PER_MSG)
            {                
                uint16_t slaveID = (uint16_t)(i/(NUMBER_MAX_EPOS_PER_SLAVE*NUMBER_BYTES_PER_MSG)); //takes only the integer part of the float that results from the division
                uint16_t eposID = (uint16_t)((i/NUMBER_BYTES_PER_MSG) - slaveID*NUMBER_MAX_EPOS_PER_SLAVE); //eposID is equivalent to nodeID-1
                uint16_t byteID = (uint16_t)(i - eposID*NUMBER_BYTES_PER_MSG - slaveID*NUMBER_MAX_EPOS_PER_SLAVE*NUMBER_BYTES_PER_MSG);
                
                writeBufferSPI[slaveID][eposID][byteID] = readBufferSerial[i];
                
                //pc.printf("ID %d\n", writeBufferSPI[1][0][0]);  
            }  
            
            /*
            //sort messages for each slave
            for(int i=0; i<NUMBER_MSG_PER_PACKET*NUMBER_BYTES_PER_MSG; i+=NUMBER_BYTES_PER_MSG)
            {
                uint8_t nodeID = readBufferSerial[i];
                
                if(nodeID>=FIRST_NODE_ID_SLAVE_1 && nodeID<FIRST_NODE_ID_SLAVE_2) //slave 1
                {           
                    for(int j=0; j<NUMBER_BYTES_PER_MSG; j++)
                    {
                        writeBufferSPI[0][i/NUMBER_BYTES_PER_MSG][j] = readBufferSerial[i+j];                        
                    }                                                                                
                    //numberCmds[0]++;                
                }
                else if(nodeID>=FIRST_NODE_ID_SLAVE_2 && nodeID<FIRST_NODE_ID_SLAVE_3) //slave 2
                {
                    for(int j=0; j<NUMBER_BYTES_PER_MSG; j++)
                    {
                        writeBufferSPI[1][i/NUMBER_BYTES_PER_MSG-NUMBER_MAX_EPOS_PER_SLAVE][j] = readBufferSerial[i+j];
                    }
                    
                    //change nodeID between 1 and 16
                    writeBufferSPI[1][i/NUMBER_BYTES_PER_MSG-NUMBER_MAX_EPOS_PER_SLAVE][0] -= NUMBER_MAX_EPOS_PER_SLAVE; //substract a multiple of 16, example : nodeID 17 will be nodeID 1 for slave nb 2
                    
                    //pc.printf("ID %d\n", writeBufferSPI[1][0][0]);
                    //numberCmds[1]++;
                    //pc.printf("ID[%d] %d\n", i/NUMBER_BYTES_PER_MSG, writeBufferSPI[1][i/NUMBER_BYTES_PER_MSG][0]);
                }
                else if(nodeID>=FIRST_NODE_ID_SLAVE_3 && nodeID<FIRST_NODE_ID_SLAVE_4) //slave 3
                {
                    for(int j=0; j<NUMBER_BYTES_PER_MSG; j++)
                    {
                        writeBufferSPI[2][i/NUMBER_BYTES_PER_MSG-2*NUMBER_MAX_EPOS_PER_SLAVE][j] = readBufferSerial[i+j];
                    }
                    
                    //change nodeID between 1 and 16
                    writeBufferSPI[2][i/NUMBER_BYTES_PER_MSG-2*NUMBER_MAX_EPOS_PER_SLAVE][0] -= 2*NUMBER_MAX_EPOS_PER_SLAVE; //substract a multiple of 16, example : nodeID 17 will be nodeID 1 for slave nb 2
                    //numberCmds[2]++;
                }   
                else if(nodeID>=FIRST_NODE_ID_SLAVE_4 && nodeID<FIRST_NODE_ID_SLAVE_5) //slave 4
                {
                    for(int j=0; j<NUMBER_BYTES_PER_MSG; j++)
                    {
                        writeBufferSPI[3][i/NUMBER_BYTES_PER_MSG-3*NUMBER_MAX_EPOS_PER_SLAVE][j] = readBufferSerial[i+j];
                    }
                    
                    //change nodeID between 1 and 16
                    writeBufferSPI[3][i/NUMBER_BYTES_PER_MSG-3*NUMBER_MAX_EPOS_PER_SLAVE][0] -= 3*NUMBER_MAX_EPOS_PER_SLAVE; //substract a multiple of 16 example : nodeID 17 will be nodeID 1 for slave nb 2
                    //numberCmds[2]++;
                } 
                else if(nodeID>=FIRST_NODE_ID_SLAVE_5 && nodeID<FIRST_NODE_ID_SLAVE_6) //slave 5 
                {
                    for(int j=0; j<NUMBER_BYTES_PER_MSG; j++)
                    {
                        writeBufferSPI[4][i/NUMBER_BYTES_PER_MSG-4*NUMBER_MAX_EPOS_PER_SLAVE][j] = readBufferSerial[i+j];
                    }
                    
                    //change nodeID between 1 and 15
                    writeBufferSPI[4][i/NUMBER_BYTES_PER_MSG-4*NUMBER_MAX_EPOS_PER_SLAVE][0] -= 4*NUMBER_MAX_EPOS_PER_SLAVE; //substract a multiple of 15, example : nodeID 16 will be nodeID 1 for slave nb 2
                    //numberCmds[2]++;
                }  
                else if(nodeID>=FIRST_NODE_ID_SLAVE_6) //slave 6
                {
                    for(int j=0; j<NUMBER_BYTES_PER_MSG; j++)
                    {
                        writeBufferSPI[5][i/NUMBER_BYTES_PER_MSG-5*NUMBER_MAX_EPOS_PER_SLAVE][j] = readBufferSerial[i+j];
                    }
                    
                    //change nodeID between 1 and 15
                    writeBufferSPI[5][i/NUMBER_BYTES_PER_MSG-5*NUMBER_MAX_EPOS_PER_SLAVE][0] -= 5*NUMBER_MAX_EPOS_PER_SLAVE; //substract a multiple of 15, example : nodeID 16 will be nodeID 1 for slave nb 2
                    //numberCmds[2]++;
                }  
                //pc.printf("ID %d\n", writeBufferSPI[1][0][0]);  
            }      
            */
            
            //pc.printf("ID %d\n", writeBufferSPI[1][0][0]);
            
            //add dummy bytes, 3 bytes because SPI receive and reply at the same time, send 5 command bytes and receive 8 data bytes
            for(int k=0; k<NUMBER_SLAVE_BOARDS; k++)
            {
                for(int i=0; i<NUMBER_MAX_EPOS_PER_SLAVE; i++)
                {   
                    for(int j=NUMBER_BYTES_PER_MSG; j<NUMBER_BYTES_TO_READ; j++)
                    {
                        writeBufferSPI[k][i][j] = DUMMY_BYTE;                        
                    }
                }
            }
            
            //now all individual SPI buffers for slaves have been created
            //compute checksum for each slave and update the variable, it'll be sent later at the end of SPI writting
            calculateSPIChecksum(); //this update the writeChecksum[k]
            
            //pc.printf("nbCmd %d %d %d\n", numberCmds[0], numberCmds[1], numberCmds[2]);   
            //pc.printf("1st Cmd %02X %02X %02X %02X %02X %02X %02X\n", writeBufferSPI[0][0][0], writeBufferSPI[0][0][1], writeBufferSPI[0][0][2], writeBufferSPI[0][0][3], writeBufferSPI[0][0][4], writeBufferSPI[0][0][5], writeBufferSPI[0][0][6]);  
            
            ledchain[0] = 1; //switch on first LED
                    
            //new commands has been grabbed and are ready to be sent to slaves            
            for(int k=0; k<NUMBER_SLAVE_BOARDS; k++)  //NUMBER_SLAVE_BOARDS for each slave
            {
                //if(k<3) ledchain[k] = 1; //switch on LED nb k
                
                
                sync_slave[k] = 1;
                
                //cs[k] = 0; //select slave
                wait_us(10); //pause so the slave can see it's been selected
                
                sync_slave[k] = 0;
                            
                cs[k] = 0;          
                spi.write(OPEN_ARROW);
                wait_us(5);
                cs[k] = 1;          
                wait_us(8); 
                
                cs[k] = 0;
                spi.write(OPEN_ARROW);
                wait_us(5);
                cs[k] = 1;
                wait_us(8);
                
                cs[k] = 0; 
                spi.write(OPEN_ARROW);
                wait_us(5);
                cs[k] = 1;
                wait_us(8);
                
                for(int i=0; i<NUMBER_MAX_EPOS_PER_SLAVE; i++) 
                {                    
                    //writeBufferSPI[k][i][0] = writeBufferSPI[k][i][0] - 0x0F;
                    
                    for(int j=0; j<NUMBER_BYTES_TO_READ; j++) 
                    {
                        cs[k] = 0;
                        readBufferSPI[k][i][j] = (char)(spi.write(writeBufferSPI[k][i][j]));
                        wait_us(5);
                        cs[k] = 1;
                        wait_us(8);
                    }
                }
                
                //finally write the command checksum and read the data checksum at the same time
                cs[k] = 0; 
                readChecksum[k] = (char)(spi.write(writeChecksum[k]));
                wait_us(5);
                cs[k] = 1; //unselect the chip slave
                wait_us(8);   
                
                                
            }
            
            ledchain[0] = 0; //switch off first LED 
            
            //pc.printf("nodeID 1 0x%02X 2 0x%02X 3 0x%02X\n", writeBufferSPI[0][0][0], writeBufferSPI[1][0][0], writeBufferSPI[2][0][0]);
            //pc.printf("nodeID 1-%d 2-%d 3-%d\n", writeBufferSPI[0][0][0], writeBufferSPI[1][0][0], writeBufferSPI[2][0][0]);
            //pc.printf("rc 0x%02X wc 0x%02X\n", readChecksum[0], writeChecksum[0]);
            //pc.printf("%02X\n", writeChecksum[2]);
          
            //now check the validity of the data
            dataValid = verifyDataChecksum();            
            
            //logicPin = 1;
            
            //compute checksum for all data from slaves
            calculateTxChecksum();
            
            //write data and checksum on Tx
            for(int k=0; k<NUMBER_SLAVE_BOARDS; k++)
            {   
                for(int i=0; i<NUMBER_MAX_EPOS_PER_SLAVE; i++)
                {
                    for(int j=0; j<NUMBER_BYTES_TO_READ; j++)
                    {
                        ros.putc(readBufferSPI[k][i][j]);
                    }
                }        
            }
            
            ros.putc(serialTxChecksum);
            
            dataValid = false; //toggle flag for next message
            
            //logicPin = 0;
            
            
            //print the array :
            /*
            for(int i=0; i<2; i++)
            { 
                pc.printf("%02X %02X %02X %02X %02X %02X %02X\n\r", readBufferSPI[0][i][0], readBufferSPI[0][i][1], readBufferSPI[0][i][2], readBufferSPI[0][i][3], readBufferSPI[0][i][4], readBufferSPI[0][i][5], readBufferSPI[0][i][6]);
            }
            */
 /*           int i=0;
            pc.printf("%02X %02X %02X %02X %02X %02X %02X\n", readBufferSPI[0][i][0], readBufferSPI[0][i][1], readBufferSPI[0][i][2], readBufferSPI[0][i][3], readBufferSPI[0][i][4], readBufferSPI[0][i][5], readBufferSPI[0][i][6]);
            i=14;
            pc.printf("%02X %02X %02X %02X %02X %02X %02X\n\r", readBufferSPI[0][i][0], readBufferSPI[0][i][1], readBufferSPI[0][i][2], readBufferSPI[0][i][3], readBufferSPI[0][i][4], readBufferSPI[0][i][5], readBufferSPI[0][i][6]);
            
            //pc.printf("\n\r");    
            logicPin = 0;     
     */       
            //logicPin = 0;
            
            cmdValid = false; //toggle flag for next message            
        } //if(cmdValid)
        
        wait_us(10);
    }       
}